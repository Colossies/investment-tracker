<link rel="stylesheet" href = "<?php echo e(asset('css/template.css')); ?>">

    <a href = "<?php echo e(url('/train/home')); ?>"> Home </a>
    <a href = "<?php echo e(url('/train/publishers')); ?>"> Publishers </a>
    <a href = "<?php echo e(url('/train/game_companies')); ?>"> Game Companies </a>
    <a href = "<?php echo e(url('/train/games')); ?>"> Games </a>



<?php /**PATH D:\Binus\1.Notes\Semester_5\WebProg\Test Projects\Fresh Install\freshInstall\resources\views/header.blade.php ENDPATH**/ ?>