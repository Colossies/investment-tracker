<link rel="stylesheet" href = "<?php echo e(asset('css/template.css')); ?>">


    <h2>This is a footer</h2>
    <!-- The only way to do great work is to love what you do. - Steve Jobs -->

<?php /**PATH D:\Binus\1.Notes\Semester_5\WebProg\Test Projects\Fresh Install\freshInstall\resources\views/footer.blade.php ENDPATH**/ ?>