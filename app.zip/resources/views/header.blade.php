<link rel="stylesheet" href = "{{ asset('css/template.css') }}">

    <a href = "{{ url('/train/home') }}"> Home </a>
    <a href = "{{ url('/train/publishers') }}"> Publishers </a>
    <a href = "{{ url('/train/game_companies') }}"> Game Companies </a>
    <a href = "{{ url('/train/games') }}"> Games </a>



