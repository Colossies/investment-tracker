<link rel="stylesheet" href = "{{ asset('css/template.css') }}">


    <h2>This is a footer</h2>
    <!-- The only way to do great work is to love what you do. - Steve Jobs -->

