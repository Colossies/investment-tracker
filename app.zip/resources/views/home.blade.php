
    @extends('template')
    @section('content')
        
        test
    @endsection
